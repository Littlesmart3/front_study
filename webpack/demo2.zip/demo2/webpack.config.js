let path = require('path')

module.exports = {
    // 入口文件
    entry: "./src/index.js",
    output: {
        filename: "bundle.js",
        // 输出的路径
        // 绝对路径
        path: path.resolve(__dirname, 'dist')
    },
    // 开发模式
    mode: 'development'
}