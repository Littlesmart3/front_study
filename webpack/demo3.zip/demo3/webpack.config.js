let path = require('path')

module.exports = {
    // 入口文件
    entry: "./src/index.js",
    output: {
        filename: "bundle.js",
        // 输出的路径
        // 绝对路径
        path: path.resolve(__dirname, 'dist')
    },
    // 开发模式
    mode: 'development',
    // loader的配置
    module: {
        // 对某种格式的文件进行抓转换处理
        rules: [
            {
                test:/\.css$/,
                use:[
                    // use数组里的loader的顺序，是从下到上。逆序执行
                    // 将js的样式内容插入到style标签里
                    "style-loader",
                    // 将cdd文件传为js
                    "css-loader"
                ]
            }
        ]
    }

}