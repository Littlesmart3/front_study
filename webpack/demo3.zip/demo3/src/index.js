import data from './data.json'
// 引入样式资源
import css from './style.css'

function fn1() {
    console.log('fn1');
}
fn1()

console.log(data);