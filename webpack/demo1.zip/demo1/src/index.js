import data from './data.json'

function fn1() {
    console.log('fn1');
}
fn1()

console.log(data);